def mostrar_menu():
    print("Menú de Opciones")
    print("1. Saludar")
    print("2. Despedirse")
    print("3. Salir")

def main():
    mostrar_menu()
    opcion = input("Elige una opción (1-3): ")
    
    if opcion == '1':
        print("¡Hola! ¿Cómo estás?")
    elif opcion == '2':
        print("¡Adiós! ¡Que tengas un buen día!")
    elif opcion == '3':
        print("Saliendo del programa...")
    else:
        print("Opción no válida. Por favor, elige una opción del 1 al 3.")

if __name__ == "__main__":
    main()
