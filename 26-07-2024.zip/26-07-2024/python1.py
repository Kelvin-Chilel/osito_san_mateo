def carcel_uno():
    return "carcel 1 seleccionada"

def carcel_dos():
    return "Carcel 2 seleccionada"

def carcel_tres():
    return "carcel 3 seleccionada"

def no_carcel():
    return "no hay carceles seleccionadas"

def switch_case(case):
    switcher = {
        1: carcel_uno,
        2: carcel_dos,
        3: carcel_tres,
    }
    
    func = switcher.get(case, no_carcel)
    
    return func()
if __name__ == "__main__":
    test_cases = [1, 2, 3, 4] 
    for case in test_cases:
        print(f"hola {case}: {switch_case(case)}")
